use anyhow::{anyhow, Result};
use num_complex::Complex;
use spec_math::cephes64;
use std::ffi::c_void;
use std::fmt;

use super::applet::Applet;

/*
 * Design Note:
 *
 * Unary complex functions are defined as:
 *      `extern "C" fn(f64, f64, &mut Complex<f64>)`
 *
 * Initially, we tried `extern "C" fn(Complex<f64>) -> Complex<f64>`.
 * However, Complex is a user-defined structure in Rust and not an
 * intrinsic type. Therefore, the C-mapping is variable. This worked
 * fine on Linux systems but not Windows that passes structures in
 * stack and not registers.
 *
 * Next, we tried `fn(Complex<f64>) -> Complex<f64>`. In practice, this
 * works but has a main shortcoming. It depends on the details of
 * Rust ABI, which is not stable. In fact, this only works when the
 * crate is compiled in release mode and not debug mode.
 *
 * Therefore, we settled on the current version, where the function
 * arguments are defined explicitely and the C-mapping is unambiguous.
 * This version has the additional benefit of allowing call elision
 * (not implemented yet).
 *
 */

#[repr(C)]
pub struct SinCos {
    pub s: f64,
    pub c: f64,
}

pub type UnaryFunc = extern "C" fn(f64) -> f64;
pub type BinaryFunc = extern "C" fn(f64, f64) -> f64;
pub type UnaryFuncCplx = extern "C" fn(f64, f64, &mut Complex<f64>);
pub type BinaryFuncCplx = extern "C" fn(f64, f64, &mut Complex<f64>);
pub type PairedUnaryFunc = extern "C" fn(f64) -> SinCos;

#[derive(Clone)]
pub enum Func {
    Unary(UnaryFunc),
    Binary(BinaryFunc),
    UnaryCplx(UnaryFuncCplx),
    BinaryCplx(BinaryFuncCplx),
    PairedUnary(PairedUnaryFunc),
    Slice {
        f_scalar: *const c_void,
        f_simd: *const c_void,
        env: *const c_void,
    },
    App(Box<Applet>),
    Recursive,
}

impl Func {
    pub fn func_ptr(&self) -> u64 {
        match self {
            Func::Unary(f) => *f as usize as u64,
            Func::Binary(f) => *f as usize as u64,
            Func::UnaryCplx(f) => *f as usize as u64,
            Func::BinaryCplx(f) => *f as usize as u64,
            Func::PairedUnary(f) => *f as usize as u64,
            Func::Slice { .. } => 0,
            Func::App(app) => match app.scalar_ptr() {
                Some(f) => f as usize as u64,
                None => 0,
            },
            Func::Recursive => 0,
        }
    }
}

unsafe impl Sync for Func {}
unsafe impl Send for Func {}

impl fmt::Debug for Func {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "<function pointer>")
    }
}

// std already links libm; an explicit #[link(name = "m")] moves it ahead of
// compiler_builtins and silently replaces the real cbrt with glibc's (~3 ulp).
#[cfg(all(target_family = "unix", feature = "libm"))]
extern "C" {
    fn csin(z: Complex<f64>) -> Complex<f64>;
    fn ccos(z: Complex<f64>) -> Complex<f64>;
    fn ctan(z: Complex<f64>) -> Complex<f64>;
    fn casin(z: Complex<f64>) -> Complex<f64>;
    fn cacos(z: Complex<f64>) -> Complex<f64>;
    fn catan(z: Complex<f64>) -> Complex<f64>;
    fn csinh(z: Complex<f64>) -> Complex<f64>;
    fn ccosh(z: Complex<f64>) -> Complex<f64>;
    fn ctanh(z: Complex<f64>) -> Complex<f64>;
    fn casinh(z: Complex<f64>) -> Complex<f64>;
    fn cacosh(z: Complex<f64>) -> Complex<f64>;
    fn catanh(z: Complex<f64>) -> Complex<f64>;
}

// 1/w for the reciprocal functions (csc, sec, cot, csch, sech, coth). `Complex::inv`
// computes conj(w)/|w|^2, which overflows for |w| > 1.3e154 (giving 0 instead of tiny
// values) and gives NaN for an infinite w. Smith's algorithm avoids the overflow, and
// 1/inf = 0 with the signs of conj(1/w) (C99 Annex G); NaN arguments stay NaN.
fn recip(w: Complex<f64>) -> Complex<f64> {
    if w.re.is_infinite() || w.im.is_infinite() {
        return Complex::new(0.0f64.copysign(w.re), (-0.0f64).copysign(w.im));
    }
    if w.re.abs() >= w.im.abs() {
        let r = w.im / w.re;
        let d = w.re + w.im * r;
        Complex::new(1.0 / d, -r / d)
    } else {
        let r = w.re / w.im;
        let d = w.re * r + w.im;
        Complex::new(r / d, -1.0 / d)
    }
}

// tanh for the default (non-libm) build. `Complex::tanh` divides sinh(2x) by
// cosh(2x) + cos(2y), which overflows to NaN for |x| > ~355 and cancels near the poles
// z = i(k + 1/2)pi, where it lost up to 1e8 ulp (and hundreds of ulp for |x|, |y| < 3).
// Instead, tanh z = sinh z conj(cosh z) / |cosh z|^2:
//
//   tanh z = (sinh x cosh x + i sin y cos y) / (sinh^2 x + cos^2 y),
//
// whose denominator is a sum of squares (no cancellation; the same formula as `libm::ctanh`).
// For |x| > 22, tanh(z) is +-1 to double precision and its imaginary part is
// 4 sin(y) cos(y) exp(-2|x|) (as in C99 ctanh).
#[allow(dead_code)] // unused with the `libm` feature
fn tanh_c(z: Complex<f64>) -> Complex<f64> {
    let (x, y) = (z.re, z.im);
    let (sy, cy) = y.sin_cos();
    if x.abs() > 22.0 {
        let e = (-2.0 * x.abs()).exp();
        Complex::new(1.0f64.copysign(x), 4.0 * sy * cy * e)
    } else {
        let (s, c) = (x.sinh(), x.cosh());
        let d = s * s + cy * cy;
        Complex::new(s * c / d, sy * cy / d)
    }
}

// tan(z) = -i tanh(iz)
#[allow(dead_code)] // unused with the `libm` feature
fn tan_c(z: Complex<f64>) -> Complex<f64> {
    let t = tanh_c(Complex::new(-z.im, z.re));
    Complex::new(t.im, -t.re)
}

pub struct VirtualTable;

impl VirtualTable {
    /// The C math library (libm) function computing `op`, for object files; None if
    /// there is none (e.g. `csc`, `sinc`, complex functions). Note that symjit's `log`
    /// is the decimal logarithm and `ln` the natural one.
    #[cfg(all(target_family = "unix", feature = "libm"))]
    pub fn c_name(op: &str) -> Option<&'static str> {
        let name = match op {
            "sin" => "sin",
            "cos" => "cos",
            "tan" => "tan",
            "sinh" => "sinh",
            "cosh" => "cosh",
            "tanh" => "tanh",
            "arcsin" => "asin",
            "arccos" => "acos",
            "arctan" => "atan",
            "arcsinh" => "asinh",
            "arccosh" => "acosh",
            "arctanh" => "atanh",
            "exp" => "exp",
            "expm1" => "expm1",
            "exp2" => "exp2",
            "ln" => "log",
            "log" => "log10",
            "log1p" => "log1p",
            "log2" => "log2",
            "cbrt" => "cbrt",
            "erf" => "erf",
            "erfc" => "erfc",
            "gamma" => "tgamma",
            "loggamma" => "lgamma",
            "power" => "pow",
            "atan2" => "atan2",
            _ => return None,
        };
        Some(name)
    }

    // Finds the function reference for op
    pub fn from_str(op: &str) -> Result<Func> {
        let f = match op {
            "sin" => Func::Unary(Self::sin),
            "sinc" => Func::Unary(Self::sinc),
            "cos" => Func::Unary(Self::cos),
            "sin_cos" => Func::PairedUnary(Self::sin_cos),
            "tan" => Func::Unary(Self::tan),
            "csc" => Func::Unary(Self::csc),
            "sec" => Func::Unary(Self::sec),
            "cot" => Func::Unary(Self::cot),
            "sinh" => Func::Unary(Self::sinh),
            "cosh" => Func::Unary(Self::cosh),
            "tanh" => Func::Unary(Self::tanh),
            "csch" => Func::Unary(Self::csch),
            "sech" => Func::Unary(Self::sech),
            "coth" => Func::Unary(Self::coth),
            "arcsin" => Func::Unary(Self::asin),
            "arccos" => Func::Unary(Self::acos),
            "arctan" => Func::Unary(Self::atan),
            "arcsinh" => Func::Unary(Self::asinh),
            "arccosh" => Func::Unary(Self::acosh),
            "arctanh" => Func::Unary(Self::atanh),
            "cbrt" => Func::Unary(Self::cbrt),
            "exp" => Func::Unary(Self::exp),
            "ln" => Func::Unary(Self::ln),
            "log" => Func::Unary(Self::log),
            "expm1" => Func::Unary(Self::expm1),
            "log1p" => Func::Unary(Self::log1p),
            "exp2" => Func::Unary(Self::exp2),
            "log2" => Func::Unary(Self::log2),
            "erf" => Func::Unary(Self::erf),
            "erfc" => Func::Unary(Self::erfc),
            "gamma" => Func::Unary(Self::gamma),
            "loggamma" => Func::Unary(Self::loggamma),
            "Si" => Func::Unary(Self::si),
            "Ci" => Func::Unary(Self::ci),
            "Shi" => Func::Unary(Self::shi),
            "Chi" => Func::Unary(Self::chi),
            "random" => Func::Unary(Self::random),
            // Binary Functions
            "power" => Func::Binary(Self::power),
            "atan2" => Func::Binary(Self::atan2),
            "arg" => Func::Unary(Self::arg),
            // Unary Complex Functions
            "cplx_sin" => Func::UnaryCplx(Self::cplx_sin),
            "cplx_sinc" => Func::UnaryCplx(Self::cplx_sinc),
            "cplx_cos" => Func::UnaryCplx(Self::cplx_cos),
            "cplx_tan" => Func::UnaryCplx(Self::cplx_tan),
            "cplx_csc" => Func::UnaryCplx(Self::cplx_csc),
            "cplx_sec" => Func::UnaryCplx(Self::cplx_sec),
            "cplx_cot" => Func::UnaryCplx(Self::cplx_cot),
            "cplx_sinh" => Func::UnaryCplx(Self::cplx_sinh),
            "cplx_cosh" => Func::UnaryCplx(Self::cplx_cosh),
            "cplx_tanh" => Func::UnaryCplx(Self::cplx_tanh),
            "cplx_csch" => Func::UnaryCplx(Self::cplx_csch),
            "cplx_sech" => Func::UnaryCplx(Self::cplx_sech),
            "cplx_coth" => Func::UnaryCplx(Self::cplx_coth),
            "cplx_arcsin" => Func::UnaryCplx(Self::cplx_asin),
            "cplx_arccos" => Func::UnaryCplx(Self::cplx_acos),
            "cplx_arctan" => Func::UnaryCplx(Self::cplx_atan),
            "cplx_arcsinh" => Func::UnaryCplx(Self::cplx_asinh),
            "cplx_arccosh" => Func::UnaryCplx(Self::cplx_acosh),
            "cplx_arctanh" => Func::UnaryCplx(Self::cplx_atanh),
            // "cplx_root" => Func::UnaryCplx(Self::cplx_root),
            "cplx_cbrt" => Func::UnaryCplx(Self::cplx_cbrt),
            "cplx_exp" => Func::UnaryCplx(Self::cplx_exp),
            "cplx_ln" => Func::UnaryCplx(Self::cplx_ln),
            "cplx_log" => Func::UnaryCplx(Self::cplx_log),
            // Complex Binary Functions
            "cplx_power" => Func::BinaryCplx(Self::cplx_power),
            "cplx_random" => Func::UnaryCplx(Self::cplx_random),
            "cplx_arg" => Func::UnaryCplx(Self::cplx_arg),
            // yield points of lockstep evaluation (`lockstep.rs`)
            #[cfg(feature = "async")]
            "_yield_" => Func::Unary(super::lockstep::yield_point),
            #[cfg(feature = "async")]
            "cplx__yield_" => Func::UnaryCplx(super::lockstep::cplx_yield_point),
            _ => {
                return Err(anyhow!("op_code {} is not found or is not supported", op));
            }
        };

        Ok(f)
    }

    pub extern "C" fn power(x: f64, y: f64) -> f64 {
        x.powf(y)
    }

    pub extern "C" fn atan2(x: f64, y: f64) -> f64 {
        x.atan2(y)
    }

    pub extern "C" fn sinc(x: f64) -> f64 {
        if x == 0.0 {
            1.0
        } else {
            x.sin() / x
        }
    }

    pub extern "C" fn sin(x: f64) -> f64 {
        x.sin()
    }

    pub extern "C" fn cos(x: f64) -> f64 {
        x.cos()
    }

    pub extern "C" fn sin_cos(x: f64) -> SinCos {
        let (s, c) = x.sin_cos();
        SinCos { s, c }
    }

    pub extern "C" fn tan(x: f64) -> f64 {
        x.tan()
    }

    pub extern "C" fn csc(x: f64) -> f64 {
        1.0 / x.sin()
    }

    pub extern "C" fn sec(x: f64) -> f64 {
        1.0 / x.cos()
    }

    pub extern "C" fn cot(x: f64) -> f64 {
        1.0 / x.tan()
    }

    pub extern "C" fn sinh(x: f64) -> f64 {
        x.sinh()
    }

    pub extern "C" fn cosh(x: f64) -> f64 {
        x.cosh()
    }

    pub extern "C" fn tanh(x: f64) -> f64 {
        x.tanh()
    }

    pub extern "C" fn csch(x: f64) -> f64 {
        1.0 / x.sinh()
    }

    pub extern "C" fn sech(x: f64) -> f64 {
        1.0 / x.cosh()
    }

    pub extern "C" fn coth(x: f64) -> f64 {
        1.0 / x.tanh()
    }

    pub extern "C" fn asin(x: f64) -> f64 {
        x.asin()
    }

    pub extern "C" fn acos(x: f64) -> f64 {
        x.acos()
    }

    pub extern "C" fn atan(x: f64) -> f64 {
        x.atan()
    }

    pub extern "C" fn asinh(x: f64) -> f64 {
        x.asinh()
    }

    pub extern "C" fn acosh(x: f64) -> f64 {
        x.acosh()
    }

    pub extern "C" fn atanh(x: f64) -> f64 {
        x.atanh()
    }

    pub extern "C" fn cbrt(x: f64) -> f64 {
        x.cbrt()
    }

    pub extern "C" fn exp(x: f64) -> f64 {
        x.exp()
    }

    pub extern "C" fn ln(x: f64) -> f64 {
        x.ln()
    }

    pub extern "C" fn log(x: f64) -> f64 {
        x.log10()
    }

    pub extern "C" fn expm1(x: f64) -> f64 {
        x.exp_m1()
    }

    pub extern "C" fn log1p(x: f64) -> f64 {
        x.ln_1p()
    }

    pub extern "C" fn exp2(x: f64) -> f64 {
        x.exp2()
    }

    pub extern "C" fn log2(x: f64) -> f64 {
        x.log2()
    }

    pub extern "C" fn gamma(x: f64) -> f64 {
        cephes64::gamma(x)
    }

    pub extern "C" fn loggamma(x: f64) -> f64 {
        cephes64::lgam(x)
    }

    pub extern "C" fn erf(x: f64) -> f64 {
        cephes64::erf(x)
    }

    pub extern "C" fn erfc(x: f64) -> f64 {
        cephes64::erfc(x)
    }

    pub extern "C" fn si(x: f64) -> f64 {
        let (s, _) = cephes64::sici(x);
        s
    }

    pub extern "C" fn ci(x: f64) -> f64 {
        let (_, c) = cephes64::sici(x);
        c
    }

    pub extern "C" fn shi(x: f64) -> f64 {
        let (s, _) = cephes64::shichi(x);
        s
    }

    pub extern "C" fn chi(x: f64) -> f64 {
        let (_, c) = cephes64::shichi(x);
        c
    }

    pub extern "C" fn random(x: f64) -> f64 {
        rand::random::<f64>() * x
    }

    pub extern "C" fn arg(_x: f64) -> f64 {
        0.0
    }

    /************** Complex Functions ***************/

    pub extern "C" fn cplx_sinc(xr: f64, xi: f64, z: &mut Complex<f64>) {
        let x = Complex::new(xr, xi);
        if x == Complex::ZERO {
            *z = Complex::ONE;
        } else {
            *z = x.sin() / x;
        }
    }

    #[cfg(all(target_family = "unix", feature = "libm"))]
    pub extern "C" fn cplx_sin(xr: f64, xi: f64, z: &mut Complex<f64>) {
        *z = unsafe { csin(Complex::new(xr, xi)) };
    }

    #[cfg(all(target_family = "unix", feature = "libm"))]
    pub extern "C" fn cplx_cos(xr: f64, xi: f64, z: &mut Complex<f64>) {
        *z = unsafe { ccos(Complex::new(xr, xi)) };
    }

    #[cfg(all(target_family = "unix", feature = "libm"))]
    pub extern "C" fn cplx_tan(xr: f64, xi: f64, z: &mut Complex<f64>) {
        *z = unsafe { ctan(Complex::new(xr, xi)) };
    }

    #[cfg(all(target_family = "unix", feature = "libm"))]
    pub extern "C" fn cplx_csc(xr: f64, xi: f64, z: &mut Complex<f64>) {
        *z = recip(unsafe { csin(Complex::new(xr, xi)) });
    }

    #[cfg(all(target_family = "unix", feature = "libm"))]
    pub extern "C" fn cplx_sec(xr: f64, xi: f64, z: &mut Complex<f64>) {
        *z = recip(unsafe { ccos(Complex::new(xr, xi)) });
    }

    #[cfg(all(target_family = "unix", feature = "libm"))]
    pub extern "C" fn cplx_cot(xr: f64, xi: f64, z: &mut Complex<f64>) {
        *z = recip(unsafe { ctan(Complex::new(xr, xi)) });
    }

    #[cfg(all(target_family = "unix", feature = "libm"))]
    pub extern "C" fn cplx_sinh(xr: f64, xi: f64, z: &mut Complex<f64>) {
        *z = unsafe { csinh(Complex::new(xr, xi)) };
    }

    #[cfg(all(target_family = "unix", feature = "libm"))]
    pub extern "C" fn cplx_cosh(xr: f64, xi: f64, z: &mut Complex<f64>) {
        *z = unsafe { ccosh(Complex::new(xr, xi)) };
    }

    #[cfg(all(target_family = "unix", feature = "libm"))]
    pub extern "C" fn cplx_tanh(xr: f64, xi: f64, z: &mut Complex<f64>) {
        *z = unsafe { ctanh(Complex::new(xr, xi)) };
    }

    #[cfg(all(target_family = "unix", feature = "libm"))]
    pub extern "C" fn cplx_csch(xr: f64, xi: f64, z: &mut Complex<f64>) {
        *z = recip(unsafe { csinh(Complex::new(xr, xi)) });
    }

    #[cfg(all(target_family = "unix", feature = "libm"))]
    pub extern "C" fn cplx_sech(xr: f64, xi: f64, z: &mut Complex<f64>) {
        *z = recip(unsafe { ccosh(Complex::new(xr, xi)) });
    }

    #[cfg(all(target_family = "unix", feature = "libm"))]
    pub extern "C" fn cplx_coth(xr: f64, xi: f64, z: &mut Complex<f64>) {
        *z = recip(unsafe { ctanh(Complex::new(xr, xi)) });
    }

    #[cfg(all(target_family = "unix", feature = "libm"))]
    pub extern "C" fn cplx_asin(xr: f64, xi: f64, z: &mut Complex<f64>) {
        *z = unsafe { casin(Complex::new(xr, xi)) };
    }

    #[cfg(all(target_family = "unix", feature = "libm"))]
    pub extern "C" fn cplx_acos(xr: f64, xi: f64, z: &mut Complex<f64>) {
        *z = unsafe { cacos(Complex::new(xr, xi)) };
    }

    #[cfg(all(target_family = "unix", feature = "libm"))]
    pub extern "C" fn cplx_atan(xr: f64, xi: f64, z: &mut Complex<f64>) {
        *z = unsafe { catan(Complex::new(xr, xi)) };
    }

    #[cfg(all(target_family = "unix", feature = "libm"))]
    pub extern "C" fn cplx_asinh(xr: f64, xi: f64, z: &mut Complex<f64>) {
        *z = unsafe { casinh(Complex::new(xr, xi)) };
    }

    #[cfg(all(target_family = "unix", feature = "libm"))]
    pub extern "C" fn cplx_acosh(xr: f64, xi: f64, z: &mut Complex<f64>) {
        *z = unsafe { cacosh(Complex::new(xr, xi)) };
    }

    #[cfg(all(target_family = "unix", feature = "libm"))]
    pub extern "C" fn cplx_atanh(xr: f64, xi: f64, z: &mut Complex<f64>) {
        *z = unsafe { catanh(Complex::new(xr, xi)) };
    }

    #[cfg(any(not(target_family = "unix"), not(feature = "libm")))]
    pub extern "C" fn cplx_sin(xr: f64, xi: f64, z: &mut Complex<f64>) {
        *z = Complex::new(xr, xi).sin();
    }

    #[cfg(any(not(target_family = "unix"), not(feature = "libm")))]
    pub extern "C" fn cplx_cos(xr: f64, xi: f64, z: &mut Complex<f64>) {
        *z = Complex::new(xr, xi).cos();
    }

    #[cfg(any(not(target_family = "unix"), not(feature = "libm")))]
    pub extern "C" fn cplx_tan(xr: f64, xi: f64, z: &mut Complex<f64>) {
        *z = tan_c(Complex::new(xr, xi));
    }

    #[cfg(any(not(target_family = "unix"), not(feature = "libm")))]
    pub extern "C" fn cplx_csc(xr: f64, xi: f64, z: &mut Complex<f64>) {
        *z = recip(Complex::new(xr, xi).sin());
    }

    #[cfg(any(not(target_family = "unix"), not(feature = "libm")))]
    pub extern "C" fn cplx_sec(xr: f64, xi: f64, z: &mut Complex<f64>) {
        *z = recip(Complex::new(xr, xi).cos());
    }

    #[cfg(any(not(target_family = "unix"), not(feature = "libm")))]
    pub extern "C" fn cplx_cot(xr: f64, xi: f64, z: &mut Complex<f64>) {
        *z = recip(tan_c(Complex::new(xr, xi)));
    }

    #[cfg(any(not(target_family = "unix"), not(feature = "libm")))]
    pub extern "C" fn cplx_sinh(xr: f64, xi: f64, z: &mut Complex<f64>) {
        *z = Complex::new(xr, xi).sinh();
    }

    #[cfg(any(not(target_family = "unix"), not(feature = "libm")))]
    pub extern "C" fn cplx_cosh(xr: f64, xi: f64, z: &mut Complex<f64>) {
        *z = Complex::new(xr, xi).cosh();
    }

    #[cfg(any(not(target_family = "unix"), not(feature = "libm")))]
    pub extern "C" fn cplx_tanh(xr: f64, xi: f64, z: &mut Complex<f64>) {
        *z = tanh_c(Complex::new(xr, xi));
    }

    #[cfg(any(not(target_family = "unix"), not(feature = "libm")))]
    pub extern "C" fn cplx_csch(xr: f64, xi: f64, z: &mut Complex<f64>) {
        *z = recip(Complex::new(xr, xi).sinh());
    }

    #[cfg(any(not(target_family = "unix"), not(feature = "libm")))]
    pub extern "C" fn cplx_sech(xr: f64, xi: f64, z: &mut Complex<f64>) {
        *z = recip(Complex::new(xr, xi).cosh());
    }

    #[cfg(any(not(target_family = "unix"), not(feature = "libm")))]
    pub extern "C" fn cplx_coth(xr: f64, xi: f64, z: &mut Complex<f64>) {
        *z = recip(tanh_c(Complex::new(xr, xi)));
    }

    #[cfg(any(not(target_family = "unix"), not(feature = "libm")))]
    pub extern "C" fn cplx_asin(xr: f64, xi: f64, z: &mut Complex<f64>) {
        *z = Complex::new(xr, xi).asin();
    }

    #[cfg(any(not(target_family = "unix"), not(feature = "libm")))]
    pub extern "C" fn cplx_acos(xr: f64, xi: f64, z: &mut Complex<f64>) {
        *z = Complex::new(xr, xi).acos();
    }

    #[cfg(any(not(target_family = "unix"), not(feature = "libm")))]
    pub extern "C" fn cplx_atan(xr: f64, xi: f64, z: &mut Complex<f64>) {
        *z = Complex::new(xr, xi).atan();
    }

    #[cfg(any(not(target_family = "unix"), not(feature = "libm")))]
    pub extern "C" fn cplx_asinh(xr: f64, xi: f64, z: &mut Complex<f64>) {
        *z = Complex::new(xr, xi).asinh();
    }

    #[cfg(any(not(target_family = "unix"), not(feature = "libm")))]
    pub extern "C" fn cplx_acosh(xr: f64, xi: f64, z: &mut Complex<f64>) {
        *z = Complex::new(xr, xi).acosh();
    }

    #[cfg(any(not(target_family = "unix"), not(feature = "libm")))]
    pub extern "C" fn cplx_atanh(xr: f64, xi: f64, z: &mut Complex<f64>) {
        *z = Complex::new(xr, xi).atanh();
    }

    /*
    pub extern "C" fn cplx_root(xr: f64, xi: f64, z: &mut Complex<f64>) {
        *z = Complex::new(xr, xi).sqrt();
    }
    */

    pub extern "C" fn cplx_cbrt(xr: f64, xi: f64, z: &mut Complex<f64>) {
        *z = Complex::new(xr, xi).cbrt();
    }

    pub extern "C" fn cplx_exp(xr: f64, xi: f64, z: &mut Complex<f64>) {
        *z = Complex::new(xr, xi).exp();
    }

    pub extern "C" fn cplx_ln(xr: f64, xi: f64, z: &mut Complex<f64>) {
        *z = Complex::new(xr, xi).ln();
    }

    pub extern "C" fn cplx_log(xr: f64, xi: f64, z: &mut Complex<f64>) {
        *z = Complex::new(xr, xi).ln();
    }

    pub extern "C" fn cplx_power(xr: f64, xi: f64, z: &mut Complex<f64>) {
        *z = Complex::new(xr, xi).powc(*z);
    }

    pub extern "C" fn cplx_random(xr: f64, xi: f64, z: &mut Complex<f64>) {
        *z = Complex::new(rand::random::<f64>(), rand::random::<f64>()) * Complex::new(xr, xi);
    }

    pub extern "C" fn cplx_arg(xr: f64, xi: f64, z: &mut Complex<f64>) {
        *z = Complex::new(Complex::new(xr, xi).arg(), 0.0);
    }
}
